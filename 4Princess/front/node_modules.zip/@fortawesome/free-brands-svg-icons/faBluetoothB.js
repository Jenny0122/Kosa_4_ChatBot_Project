'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'bluetooth-b';
var width = 320;
var height = 512;
var aliases = [];
var unicode = 'f294';
var svgPathData = 'M196.5 260l92.63-103.3L143.1 0v206.3l-86.11-86.11-31.41 31.41 108.1 108.4L25.61 368.4l31.41 31.41 86.11-86.11L145.8 512l148.6-148.6-97.91-103.3zm40.86-102.1l-49.98 49.98-.338-100.3 50.31 50.32zM187.4 313l49.98 49.98-50.31 50.32 .338-100.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBluetoothB = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;